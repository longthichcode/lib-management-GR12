package com.knf.dev.librarymanagementsystem.vo;

public record CategoryRecord(Long id,String name) {

}
